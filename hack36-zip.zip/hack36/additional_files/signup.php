<?php

$con =mysqli_connect('localhost','root');

if($con){
    echo"sign in successful";
}else{
    echo"error";

}

my sqli_select_db($con, 'grameen-organicuserdata');

$name = $_POST['name'];
$phone-no =$_POST['phone-no'];
$email-id = $_POST['mail-id'];
$password = $_POST['password'];
$address = $_POST['address'];
$query = "insert intgrameen-organicuserdata (name,phone-no,email-id,password,address)
values ('$name', '$phone-no',email-id','password','address')";

mysql_query($con,$query );

?>


